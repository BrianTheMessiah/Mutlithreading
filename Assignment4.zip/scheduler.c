#include <stdlib.h>
#include <stdio.h>


#include "simulator.h"
#include "scheduler.h"
#include "queue.h"

void *readyQueue;
void *holder; 
thread_t *threading = NULL; 
int time; 
enum algorithm code; 
unsigned int quant; 

typedef struct{
    unsigned int arrived;
    unsigned int finish;
    unsigned int wait;
    unsigned int accumWait; 
    unsigned int left; 
    unsigned int ticks; 
    thread_t *thread;
}whereThread_t; 

static bool inner_equalitor(void *whereThread, void *thread) {
  return ((whereThread_t*)whereThread)->thread == (thread_t*)thread;
}

static int inner_comparator(void *partA, void *partB) {
  return ((thread_t*)partA)->priority - ((thread_t*)partB)->priority;
 }

static int length_comparator(void *partA, void *partB) {
  return ((thread_t*)partA)->length - ((thread_t*)partB)->length;
}

static int remaining_comparator(void *threada, void *threadb) {
  whereThread_t *founda = queue_find(holder, inner_equalitor, (thread_t*)threada);
  whereThread_t *foundb = queue_find(holder, inner_equalitor, (thread_t*)threadb);
  return founda->left - foundb->left;
}

void scheduler(enum algorithm algorithm, unsigned int quantum) {
  readyQueue = queue_create();
  holder = queue_create(); 
  code = algorithm; 
  quant = quantum; 
}


whereThread_t* putBack(){
  whereThread_t *putBack = queue_find(holder, inner_equalitor, threading);
  putBack->wait = sim_time(); 

  thread_t *prev = threading;
  queue_enqueue(readyQueue, prev);

  return putBack; 
}

whereThread_t* settingNew(){
  threading = queue_dequeue(readyQueue);
  whereThread_t *found = queue_find(holder, inner_equalitor, threading); 
  found->accumWait += sim_time() - found->wait; 
  found->ticks = sim_time();
  sim_dispatch(threading);

  return found; 
}

void tick() { 
  switch(code){
    case 0: 
      if(queue_size(readyQueue) > 0 && threading == NULL){
        settingNew(); 
      }

    break;

    case 1:
      if(threading != NULL) {
        whereThread_t *curr = queue_find(holder, inner_equalitor, threading);
        if (curr->ticks + quant == sim_time()) {
          if (queue_size(readyQueue) > 0) {
            putBack();
            settingNew();
          }

          else {
            curr->ticks = sim_time();
          }
        }
      }

      if(threading == NULL && queue_size(readyQueue) > 0){
        settingNew();
      }
    break;
    
    case 2:
      if(queue_size(readyQueue) > 0 && threading == NULL){
        queue_sort(readyQueue, inner_comparator);
        settingNew();
      }
    break;

    case 3:
      if (queue_size(readyQueue) > 0) {
        queue_sort(readyQueue, inner_comparator);
        thread_t *header = queue_head(readyQueue);

        if (threading == NULL) {
          settingNew(); 
        }

        else if (header->priority < threading->priority) {
          putBack();
          settingNew();
        }
      }
    break;

    case 4:
      if(queue_size(readyQueue) > 0 && threading == NULL){
        queue_sort(readyQueue, length_comparator);
        settingNew();
      }
    break;

    
    case 5:
      if (queue_size(readyQueue) > 0) {
        queue_sort(readyQueue, length_comparator);
        thread_t *header = queue_head(readyQueue);

        if (threading == NULL) {
          settingNew();
        }

        else if (header->length < threading->length) {
          putBack();
          settingNew(); 
        }
      }
    break;

    case 6:
      if(queue_size(readyQueue) > 0 && threading == NULL){
        queue_sort(readyQueue, remaining_comparator); 
        settingNew(); 
      }
    break;
    
    case 7:
      if (queue_size(readyQueue) > 0) {
        queue_sort(readyQueue, remaining_comparator);
        thread_t *header = queue_head(readyQueue);
        whereThread_t *found = queue_find(holder, inner_equalitor, header);
        whereThread_t *foundRun = queue_find(holder, inner_equalitor, threading);

        if (threading == NULL) {
          settingNew();
        }

        else if (found->left < foundRun->left) {   
          putBack(); 
          settingNew();
        }
      }
    break;
  }
  if(threading != NULL){
    whereThread_t *found = queue_find(holder, inner_equalitor, threading);
    found->left--; 
  }
}

void sys_exec(thread_t *t) {
  whereThread_t *times = (whereThread_t *)malloc(sizeof(whereThread_t));
  times->arrived = sim_time();
  times->finish = 0;  
  times->wait = sim_time(); 
  times->thread = t; 
  times->accumWait = 0; 
  times->ticks = 0;
  times->left = t->length; 
  queue_enqueue(holder, times); 
  queue_enqueue(readyQueue, t);
}

void sys_exit(thread_t *t) {
  threading = NULL; 
  whereThread_t *found = queue_find(holder, inner_equalitor, t); 
  found->finish = sim_time(); 
}

void sys_read(thread_t *t) {
  threading = NULL; 
  whereThread_t *found = queue_find(holder, inner_equalitor, t); 
  found->wait = sim_time()+1; 
}

void sys_write(thread_t *t) {
  threading = NULL; 
  whereThread_t *found = queue_find(holder, inner_equalitor, t); 
  found->wait = sim_time()+1;
}

void io_complete(thread_t *t) {
  whereThread_t *found = queue_find(holder, inner_equalitor, t); 
  found->wait = sim_time()+1; 
  queue_enqueue(readyQueue, t); 
}

void io_starting(thread_t *t) {
  whereThread_t *found = queue_find(holder, inner_equalitor, t); 
  found->accumWait += sim_time() - found->wait; 
}

stats_t *stats() {
  int thread_count = queue_size(holder); 
  stats_t *stats = malloc(sizeof(stats_t));
  stats->tstats = malloc(sizeof(stats_t) * thread_count);

  int total_wait = 0, total_turn = 0, i = 0;
  whereThread_t *header = queue_dequeue(holder); 
  do
  {
    stats->tstats[i].tid = header->thread->tid;
    stats->tstats[i].waiting_time = header->accumWait;
    stats->tstats[i].turnaround_time = header->finish - header->arrived + 1;
    
    total_wait += stats->tstats[i].waiting_time;
    total_turn += stats->tstats[i].turnaround_time;

    free(header); 
    header = queue_dequeue(holder); 
    i++; 
  }while(header != NULL);
  
  stats->waiting_time = total_wait / thread_count;
  stats->turnaround_time = total_turn / thread_count;
  stats->thread_count = thread_count; 

  return stats;
}
